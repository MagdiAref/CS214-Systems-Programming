# PA1-Systems

This project consists of 5 smaller coding projects 
each will need to a makefile and no test cases were used for the pre grading
